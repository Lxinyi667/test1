## developer-roadmap
> "Дорожная карта" веб разработчика в 2020 году

[![](https://img.shields.io/badge/-Roadmaps%20-0a0a0a.svg?style=flat&colorA=0a0a0a)](http://roadmap.sh)
[![](https://img.shields.io/badge/-Guides-0a0a0a.svg?style=flat&colorA=0a0a0a)](http://roadmap.sh/guides)
[![](https://img.shields.io/badge/%E2%9D%A4-YouTube%20Channel-0a0a0a.svg?style=flat&colorA=0a0a0a)](https://www.youtube.com/channel/UCA0H2KIWgWTwpTFjSxp0now/playlists)

## "Дорожная карта" Frontend разработчика

![](./img/frontend-map.png)

## "Дорожная карта" Backend разработчика

![](./img/backend-map.png)

## "Дорожная карта" DevOps'а

![](./img/devops-map.png)
