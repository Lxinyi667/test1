## developer-roadmap
> 2020-yilda Web dasturchi "yo'l xaritasi"

[![](https://img.shields.io/badge/-Roadmaps%20-0a0a0a.svg?style=flat&colorA=0a0a0a)](http://roadmap.sh)
[![](https://img.shields.io/badge/-Guides-0a0a0a.svg?style=flat&colorA=0a0a0a)](http://roadmap.sh/guides)
[![](https://img.shields.io/badge/%E2%9D%A4-YouTube%20Channel-0a0a0a.svg?style=flat&colorA=0a0a0a)](https://www.youtube.com/channel/UCA0H2KIWgWTwpTFjSxp0now/playlists)

## Kirish

![Veb-dasturchi yo'l xaritasi](./img/intro-wireframe.png)

## Frontend dasturchi "yo'l xaritasi"

![](./img/front-end-map.png)

## Backend dasturchi "yo'l xaritasi"

![](./img/back-end-map.png)

## DevOps "yo'l xaritasi"

![](./img/devops.png)

## 🚦 
Agar siz biron bir yo'l xaritasini yaxshilash mumkin deb hisoblasangiz, uni Issue'larda muhokama qilishdan qo'rqmang.